<?php
return array (
  'id' => '010001',
  'name' => '易橙',
  'orderIdPrefix' => 'EC',
  'template' => '',
  'class' => 'EC',
  'unit' => '点券',
  'exchangeRate' => 100,
  'isPayGame' => '0',
);


