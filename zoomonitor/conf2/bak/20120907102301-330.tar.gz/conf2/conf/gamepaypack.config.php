<?php
return array (
  1 => 
  array (
    'id' => '1',
    'vid' => '020001',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  2 => 
  array (
    'id' => '2',
    'vid' => '020001',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  3 => 
  array (
    'id' => '3',
    'vid' => '020001',
    'paymentid' => '3',
    'packageid' => 
    array (
      0 => '2',
      1 => '5',
      2 => '6',
    ),
    'packtype' => '2',
  ),
  4 => 
  array (
    'id' => '4',
    'vid' => '020001',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '8',
      6 => '9',
    ),
    'packtype' => '2',
  ),
  5 => 
  array (
    'id' => '5',
    'vid' => '020001',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  6 => 
  array (
    'id' => '6',
    'vid' => '020001',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  7 => 
  array (
    'id' => '7',
    'vid' => '020001',
    'paymentid' => '8',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  8 => 
  array (
    'id' => '8',
    'vid' => '020002',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  9 => 
  array (
    'id' => '9',
    'vid' => '020002',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  10 => 
  array (
    'id' => '10',
    'vid' => '020002',
    'paymentid' => '3',
    'packageid' => 
    array (
      0 => '2',
      1 => '5',
      2 => '6',
    ),
    'packtype' => '2',
  ),
  11 => 
  array (
    'id' => '11',
    'vid' => '020002',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '8',
      6 => '9',
    ),
    'packtype' => '2',
  ),
  12 => 
  array (
    'id' => '12',
    'vid' => '020002',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  13 => 
  array (
    'id' => '13',
    'vid' => '020002',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  14 => 
  array (
    'id' => '14',
    'vid' => '020002',
    'paymentid' => '8',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  15 => 
  array (
    'id' => '15',
    'vid' => '020003',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  16 => 
  array (
    'id' => '16',
    'vid' => '020003',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  17 => 
  array (
    'id' => '17',
    'vid' => '020003',
    'paymentid' => '3',
    'packageid' => 
    array (
      0 => '2',
      1 => '5',
      2 => '6',
    ),
    'packtype' => '2',
  ),
  18 => 
  array (
    'id' => '18',
    'vid' => '020003',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '8',
      6 => '9',
    ),
    'packtype' => '2',
  ),
  19 => 
  array (
    'id' => '19',
    'vid' => '020003',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  20 => 
  array (
    'id' => '20',
    'vid' => '020003',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  21 => 
  array (
    'id' => '21',
    'vid' => '020003',
    'paymentid' => '8',
    'packageid' => 
    array (
      0 => '7',
    ),
    'packtype' => '2',
  ),
  22 => 
  array (
    'id' => '22',
    'vid' => '020004',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  23 => 
  array (
    'id' => '23',
    'vid' => '020004',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  24 => 
  array (
    'id' => '24',
    'vid' => '020004',
    'paymentid' => '3',
    'packageid' => 
    array (
      0 => '2',
      1 => '5',
      2 => '6',
    ),
    'packtype' => '2',
  ),
  25 => 
  array (
    'id' => '25',
    'vid' => '020004',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '8',
      6 => '9',
    ),
    'packtype' => '2',
  ),
  26 => 
  array (
    'id' => '26',
    'vid' => '020004',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  27 => 
  array (
    'id' => '27',
    'vid' => '020004',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  28 => 
  array (
    'id' => '28',
    'vid' => '020004',
    'paymentid' => '8',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  29 => 
  array (
    'id' => '29',
    'vid' => '020005',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  30 => 
  array (
    'id' => '30',
    'vid' => '020005',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  31 => 
  array (
    'id' => '31',
    'vid' => '020005',
    'paymentid' => '3',
    'packageid' => 
    array (
      0 => '2',
      1 => '5',
      2 => '6',
    ),
    'packtype' => '2',
  ),
  32 => 
  array (
    'id' => '32',
    'vid' => '020005',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '8',
      6 => '9',
    ),
    'packtype' => '2',
  ),
  33 => 
  array (
    'id' => '33',
    'vid' => '020005',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '2',
  ),
  34 => 
  array (
    'id' => '34',
    'vid' => '020005',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
      6 => '10',
    ),
    'packtype' => '2',
  ),
  35 => 
  array (
    'id' => '35',
    'vid' => '020005',
    'paymentid' => '8',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  36 => 
  array (
    'id' => '36',
    'vid' => '010001',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '1',
  ),
  37 => 
  array (
    'id' => '37',
    'vid' => '010001',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '1',
  ),
  38 => 
  array (
    'id' => '38',
    'vid' => '010001',
    'paymentid' => '3',
    'packageid' => 
    array (
    ),
    'packtype' => '1',
  ),
  39 => 
  array (
    'id' => '39',
    'vid' => '010001',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '8',
      6 => '9',
    ),
    'packtype' => '1',
  ),
  40 => 
  array (
    'id' => '40',
    'vid' => '010001',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '3',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '1',
  ),
  41 => 
  array (
    'id' => '41',
    'vid' => '010001',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '4',
      2 => '5',
      3 => '6',
      4 => '8',
      5 => '9',
    ),
    'packtype' => '1',
  ),
  42 => 
  array (
    'id' => '42',
    'vid' => '010001',
    'paymentid' => '8',
    'packageid' => 
    array (
    ),
    'packtype' => '1',
  ),
  43 => 
  array (
    'id' => '43',
    'vid' => '020001',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '12',
      1 => '13',
      2 => '14',
      3 => '15',
      4 => '16',
      5 => '17',
      6 => '18',
      7 => '19',
      8 => '20',
      9 => '21',
    ),
    'packtype' => '2',
  ),
  44 => 
  array (
    'id' => '44',
    'vid' => '020002',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '12',
      1 => '13',
      2 => '14',
      3 => '15',
      4 => '16',
      5 => '17',
      6 => '18',
      7 => '19',
      8 => '20',
      9 => '21',
    ),
    'packtype' => '2',
  ),
  45 => 
  array (
    'id' => '45',
    'vid' => '010001',
    'paymentid' => '7',
    'packageid' => 
    array (
    ),
    'packtype' => '1',
  ),
  46 => 
  array (
    'id' => '46',
    'vid' => '020005',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '12',
      1 => '13',
      2 => '14',
      3 => '15',
      4 => '16',
      5 => '17',
      6 => '18',
      7 => '19',
      8 => '20',
      9 => '21',
    ),
    'packtype' => '2',
  ),
  47 => 
  array (
    'id' => '47',
    'vid' => '020004',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '12',
      1 => '13',
      2 => '14',
      3 => '15',
      4 => '16',
      5 => '17',
      6 => '18',
      7 => '19',
      8 => '20',
      9 => '21',
    ),
    'packtype' => '2',
  ),
  48 => 
  array (
    'id' => '48',
    'vid' => '020003',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '12',
      1 => '13',
      2 => '14',
      3 => '15',
      4 => '16',
      5 => '17',
      6 => '18',
      7 => '19',
      8 => '20',
      9 => '21',
    ),
    'packtype' => '2',
  ),
  49 => 
  array (
    'id' => '49',
    'vid' => '020006',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  50 => 
  array (
    'id' => '50',
    'vid' => '020006',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '1',
      1 => '2',
      2 => '3',
      3 => '4',
      4 => '5',
      5 => '6',
      6 => '7',
      7 => '8',
      8 => '9',
      9 => '10',
      10 => '11',
    ),
    'packtype' => '2',
  ),
  51 => 
  array (
    'id' => '51',
    'vid' => '020006',
    'paymentid' => '3',
    'packageid' => 
    array (
      0 => '2',
      1 => '5',
      2 => '6',
    ),
    'packtype' => '2',
  ),
  52 => 
  array (
    'id' => '52',
    'vid' => '020006',
    'paymentid' => '4',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '7',
      6 => '8',
      7 => '9',
    ),
    'packtype' => '2',
  ),
  53 => 
  array (
    'id' => '53',
    'vid' => '020006',
    'paymentid' => '5',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '7',
      6 => '8',
      7 => '9',
    ),
    'packtype' => '2',
  ),
  54 => 
  array (
    'id' => '54',
    'vid' => '020006',
    'paymentid' => '6',
    'packageid' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '5',
      4 => '6',
      5 => '7',
      6 => '8',
      7 => '9',
    ),
    'packtype' => '2',
  ),
  55 => 
  array (
    'id' => '55',
    'vid' => '020006',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '13',
      1 => '14',
      2 => '15',
      3 => '16',
      4 => '17',
      5 => '18',
      6 => '19',
      7 => '20',
      8 => '21',
    ),
    'packtype' => '2',
  ),
  101 => 
  array (
    'id' => '101',
    'vid' => '020007',
    'paymentid' => '1',
    'packageid' => 
    array (
      0 => '22',
    ),
    'packtype' => '2',
  ),
  102 => 
  array (
    'id' => '102',
    'vid' => '020007',
    'paymentid' => '2',
    'packageid' => 
    array (
      0 => '22',
    ),
    'packtype' => '2',
  ),
  103 => 
  array (
    'id' => '103',
    'vid' => '020007',
    'paymentid' => '3',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  104 => 
  array (
    'id' => '104',
    'vid' => '020007',
    'paymentid' => '4',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  105 => 
  array (
    'id' => '105',
    'vid' => '020007',
    'paymentid' => '5',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  106 => 
  array (
    'id' => '106',
    'vid' => '020007',
    'paymentid' => '6',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
  107 => 
  array (
    'id' => '107',
    'vid' => '020007',
    'paymentid' => '7',
    'packageid' => 
    array (
      0 => '12',
    ),
    'packtype' => '2',
  ),
  108 => 
  array (
    'id' => '108',
    'vid' => '020007',
    'paymentid' => '8',
    'packageid' => 
    array (
    ),
    'packtype' => '2',
  ),
);


