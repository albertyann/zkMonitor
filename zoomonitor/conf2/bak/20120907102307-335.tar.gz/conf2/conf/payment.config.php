<?php
return array (
  1 => 
  array (
    'id' => '1',
    'code' => 'YB',
    'name' => '易宝支付',
    'show_name' => '网上银行',
    'isopen' => '1',
    'sort' => '1',
  ),
  2 => 
  array (
    'id' => '2',
    'code' => 'AL',
    'name' => '支付宝',
    'show_name' => '支付宝',
    'isopen' => '1',
    'sort' => '2',
  ),
  3 => 
  array (
    'id' => '3',
    'code' => 'JW',
    'name' => '骏网一卡通',
    'show_name' => '骏网一卡通',
    'isopen' => '1',
    'sort' => '3',
  ),
  4 => 
  array (
    'id' => '4',
    'code' => 'YBDX',
    'name' => '易宝电信',
    'show_name' => '电信充值卡',
    'isopen' => '1',
    'sort' => '4',
  ),
  5 => 
  array (
    'id' => '5',
    'code' => 'YBLT',
    'name' => '易宝联通',
    'show_name' => '联通充值卡',
    'isopen' => '1',
    'sort' => '5',
  ),
  6 => 
  array (
    'id' => '6',
    'code' => 'YBSZX',
    'name' => '易宝神州行',
    'show_name' => '神州行充值卡',
    'isopen' => '1',
    'sort' => '6',
  ),
  7 => 
  array (
    'id' => '7',
    'code' => 'EC',
    'name' => '易橙点券',
    'show_name' => '易橙点券',
    'isopen' => '1',
    'sort' => '0',
  ),
  8 => 
  array (
    'id' => '8',
    'code' => 'SD',
    'name' => '盛付通',
    'show_name' => '盛付通',
    'isopen' => '1',
    'sort' => '0',
  ),
);

