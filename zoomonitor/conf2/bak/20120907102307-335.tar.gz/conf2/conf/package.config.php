<?php
return array (
  1 => 
  array (
    'id' => '1',
    'price' => '5',
    'currency' => '元',
    'title' => '充值5元',
    'isopen' => '1',
  ),
  2 => 
  array (
    'id' => '2',
    'price' => '10',
    'currency' => '元',
    'title' => '充值10元',
    'isopen' => '1',
  ),
  3 => 
  array (
    'id' => '3',
    'price' => '20',
    'currency' => '元',
    'title' => '充值20元',
    'isopen' => '1',
  ),
  4 => 
  array (
    'id' => '4',
    'price' => '30',
    'currency' => '元',
    'title' => '充值30元',
    'isopen' => '1',
  ),
  5 => 
  array (
    'id' => '5',
    'price' => '50',
    'currency' => '元',
    'title' => '充值50元',
    'isopen' => '1',
  ),
  6 => 
  array (
    'id' => '6',
    'price' => '100',
    'currency' => '元',
    'title' => '充值100元',
    'isopen' => '1',
  ),
  7 => 
  array (
    'id' => '7',
    'price' => '200',
    'currency' => '元',
    'title' => '充值200元',
    'isopen' => '1',
  ),
  8 => 
  array (
    'id' => '8',
    'price' => '300',
    'currency' => '元',
    'title' => '充值300元',
    'isopen' => '1',
  ),
  9 => 
  array (
    'id' => '9',
    'price' => '500',
    'currency' => '元',
    'title' => '充值500元',
    'isopen' => '1',
  ),
  10 => 
  array (
    'id' => '10',
    'price' => '1000',
    'currency' => '元',
    'title' => '充值1000元',
    'isopen' => '1',
  ),
  11 => 
  array (
    'id' => '11',
    'price' => '2000',
    'currency' => '元',
    'title' => '充值2000元',
    'isopen' => '1',
  ),
  12 => 
  array (
    'id' => '12',
    'price' => '100',
    'currency' => '易橙点券',
    'title' => '充值100易橙点券',
    'isopen' => '1',
  ),
  13 => 
  array (
    'id' => '13',
    'price' => '500',
    'currency' => '易橙点券',
    'title' => '充值500易橙点券',
    'isopen' => '1',
  ),
  14 => 
  array (
    'id' => '14',
    'price' => '1000',
    'currency' => '易橙点券',
    'title' => '充值1000易橙点券',
    'isopen' => '1',
  ),
  15 => 
  array (
    'id' => '15',
    'price' => '2000',
    'currency' => '易橙点券',
    'title' => '充值2000易橙点券',
    'isopen' => '1',
  ),
  16 => 
  array (
    'id' => '16',
    'price' => '5000',
    'currency' => '易橙点券',
    'title' => '充值5000易橙点券',
    'isopen' => '1',
  ),
  17 => 
  array (
    'id' => '17',
    'price' => '10000',
    'currency' => '易橙点券',
    'title' => '充值10000易橙点券',
    'isopen' => '1',
  ),
  18 => 
  array (
    'id' => '18',
    'price' => '20000',
    'currency' => '易橙点券',
    'title' => '充值20000易橙点券',
    'isopen' => '1',
  ),
  19 => 
  array (
    'id' => '19',
    'price' => '50000',
    'currency' => '易橙点券',
    'title' => '充值50000易橙点券',
    'isopen' => '1',
  ),
  20 => 
  array (
    'id' => '20',
    'price' => '100000',
    'currency' => '易橙点券',
    'title' => '充值10万易橙点券',
    'isopen' => '1',
  ),
  21 => 
  array (
    'id' => '21',
    'price' => '200000',
    'currency' => '易橙点券',
    'title' => '充值20万易橙点券',
    'isopen' => '1',
  ),
  22 => 
  array (
    'id' => '22',
    'price' => '1',
    'currency' => '元',
    'title' => '充值1元',
    'isopen' => '1',
  ),
  23 => 
  array (
    'id' => '23',
    'price' => '100',
    'currency' => '易橙点券',
    'title' => '充值100易橙点券',
    'isopen' => '1',
  ),
  24 => 
  array (
    'id' => '24',
    'price' => '0',
    'currency' => '元',
    'title' => '充值1易橙点券',
    'isopen' => '1',
  ),
);

